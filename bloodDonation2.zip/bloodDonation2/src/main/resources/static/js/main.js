
(function($) {

  $('#bloodgroup').parent().append('<ul class="list-item" id="newbloodgroup" name="bloodgroup"></ul>');
  $('#bloodgroup option').each(function(){
      $('#newbloodgroup').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
  });
  $('#bloodgroup').remove();
  $('#newbloodgroup').attr('id', 'bloodgroup');
  $('#bloodgroup li').first().addClass('init');
  $("#bloodgroup").on("click", ".init", function() {
      $(this).closest("#bloodgroup").children('li:not(.init)').toggle();
  });
  
  var allOptions = $("#bloodgroup").children('li:not(.init)');
  $("#bloodgroup").on("click", "li:not(.init)", function() {
      allOptions.removeClass('selected');
      $(this).addClass('selected');
      $("#bloodgroup").children('.init').html($(this).html());
      allOptions.toggle();
  });
  
/*  
  (function($) {

  $('#city1').parent().append('<ul class="list-item" id="newcity1" name="city1"></ul>');
  $('#city1 option').each(function(){
      $('#newcity1').append('<li value="' + $(this).val() + '">'+$(this).text()+'</li>');
  });
  $('#city1').remove();
  $('#newcity1').attr('id', 'city1');
  $('#city1 li').first().addClass('init');
  $("#city1").on("click", ".init", function() {
      $(this).closest("#city1").children('li:not(.init)').toggle();
  });
  
  var allOptions = $("#city1").children('li:not(.init)');
  $("#city1").on("click", "li:not(.init)", function() {
      allOptions.removeClass('selected');
      $(this).addClass('selected');
      $("#city1").children('.init').html($(this).html());
      allOptions.toggle();
  });
*/
  var marginSlider = document.getElementById('slider-margin');
  if (marginSlider != undefined) {
      noUiSlider.create(marginSlider, {
            start: [500],
            step: 10,
            connect: [true, false],
            tooltips: [true],
            range: {
                'min': 0,
                'max': 1000
            },
            format: wNumb({
                decimals: 0,
                thousand: ',',
                prefix: '$ ',
            })
    });
  }
  $('#reset').on('click', function(){
      $('#register-form').reset();
  });

  $('#register-form').validate({
    rules : {
        first_name : {
            required: true,
        },
        last_name : {
            required: true,
        },
        company : {
            required: true
        },
        email : {
            required: true,
            email : true
        },
        phone_number : {
            required: true,
        }
    },
    onfocusout: function(element) {
        $(element).valid();
    },
});

    jQuery.extend(jQuery.validator.messages, {
        required: "",
        remote: "",
        email: "",
        url: "",
        date: "",
        dateISO: "",
        number: "",
        digits: "",
        creditcard: "",
        equalTo: ""
    });
})(jQuery);