package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Admin;
//import com.example.demo.model.RequestBloodPrint;
//import com.example.demo.model.RequestBloodPrintDetail;
import com.example.demo.model.SaveRequestBloodPrintDetail;
import com.example.demo.repository.bloodDonerRegisterRepository;
import com.example.demo.repository.saveRequestBloodPrintDetailRepository;

@Controller
public class adminController {
	@Autowired
	saveRequestBloodPrintDetailRepository srbpdr;
	@Autowired
	SaveRequestBloodPrintDetail srbpd;
	
	
	@Autowired
	bloodDonerRegisterRepository bdrr;
	
	@Autowired
	Admin ad;
	
	@RequestMapping("admin")
	public ModelAndView doConfirm() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("adminPage");
		return mv;
	}
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@RequestMapping("redirect3")
	public ModelAndView reqBloodRes(HttpServletRequest req){
		ModelAndView mv=new ModelAndView();
		Query query = new Query();
		query.fields().include("fullname");
		query.fields().include("bloodgroup");
		query.fields().include("city");
	
		List<Admin> request11 = mongoTemplate.find(query, Admin.class);
		mv.setViewName("adminPage2");
		mv.addObject("request22", request11);
		return mv;
	}
	
	@RequestMapping("redirect4")
	public ModelAndView reqBloodRes1(HttpServletRequest req,@RequestParam("name") String s1,@RequestParam("name1") String s2,@RequestParam("name2") String s3) {
		ModelAndView mv = new ModelAndView();
		
		srbpd.setPatientname(s1);
		srbpd.setBloodgroup(s2);
		srbpd.setCity(s3);
		
		srbpdr.insert(srbpd);
		
		return mv;
	}

}
