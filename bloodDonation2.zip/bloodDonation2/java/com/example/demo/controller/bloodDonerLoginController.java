package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.BloodDonerLogin;
import com.example.demo.model.BloodDonerRegister;
import com.example.demo.repository.bloodDonerRegisterRepository;

@Controller
public class bloodDonerLoginController {
	
	@Autowired
	bloodDonerRegisterRepository bdrr;
	
	@Autowired
	BloodDonerRegister bdr;
	
	@Autowired
	BloodDonerLogin bdl;
	
	@RequestMapping("/logout")
	public ModelAndView Logout(HttpSession ss)
	{
		ModelAndView mv=new ModelAndView();
		ss.invalidate();
		mv.setViewName("donerLogin");
		mv.addObject("message","Logout Successfully!");
		return mv;
	}
	
	@RequestMapping("login")
	public ModelAndView DonerLogin() {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("donerLogin");
		mv.addObject("bloodDonerLogin",new BloodDonerLogin());
		return mv;
	}
	
	@RequestMapping("loginProcess")
	public ModelAndView doLogin(@Valid @ModelAttribute("bloodDonerLogin") BloodDonerLogin bdl,
            BindingResult result, HttpServletRequest req,HttpSession session) {
		ModelAndView mv=new ModelAndView();
		bdr=bdrr.findByuserid(req.getParameter("userid"));
		System.out.println(bdr);
		if(bdr!=null && bdr.getPassword().equals(req.getParameter("password"))) {
			mv.setViewName("success");
			mv.addObject("fullname",bdr.getUserid());
			session.setAttribute("pom",bdr.getUserid());
		}else {
			mv.setViewName("donerLogin");
			mv.addObject("bdl",bdl);
			mv.addObject("message", "Username or Password is wrong!!");
		}
		
		return mv;
	}

}
