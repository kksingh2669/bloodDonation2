package com.example.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.RecentDoner;
import com.example.demo.model.RequestBloodPrintDetail;
import com.example.demo.model.SaveRequestBloodPrintDetail;
import com.example.demo.repository.saveRequestBloodPrintDetailRepository;

@Controller
public class recentDonerController {
	@Autowired
	saveRequestBloodPrintDetailRepository srbpdr;
	@Autowired
	SaveRequestBloodPrintDetail srbpd;
	
	@Autowired
	MongoTemplate mongoTemplate;

	@RequestMapping("redirect5")
	public ModelAndView recentDoner(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView();
		Query query = new Query();
		query.fields().include("patientname");
		query.fields().include("bloodgroup");
		query.fields().include("city");

		List<RecentDoner> request55 = mongoTemplate.find(query, RecentDoner.class);
		mv.setViewName("recentDoner");
		mv.addObject("request5", request55);
		return mv;
	}

}
