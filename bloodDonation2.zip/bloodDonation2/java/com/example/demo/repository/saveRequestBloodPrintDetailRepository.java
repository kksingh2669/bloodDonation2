package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.SaveRequestBloodPrintDetail;

public interface saveRequestBloodPrintDetailRepository extends MongoRepository<SaveRequestBloodPrintDetail, String> {
	//SaveRequestBloodPrintDetail findBypatientname(String patientname);

}
